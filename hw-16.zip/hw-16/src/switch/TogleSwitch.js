import AuthContext from '../components/store/auth_context'
import './switchStyle.css'
// import AuthContext from '../components/store/auth_context'
import {useContext} from 'react'

function Switch() {
  const switcherData=useContext(AuthContext)
  return (
    <label htmlFor="checkbox" className="toggler">
      <input
        type="checkbox"
        id="checkbox"
        onClick={() => switcherData.onSwitch((prevState) => !prevState)}
      />
      <span className="ball"></span>
      <i className="ri-sun-line sun">&#9728;</i>
      <i className="ri-moon-line moon">&#9681;</i>
    </label>
  )
}
export default Switch
