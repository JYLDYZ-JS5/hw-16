import { useState, useEffect } from 'react' //импортируем useEffect
import Login from './components/Login/Login'
import MainHeader from './components/MainHeader/MainHeader'
import Home from './components/Home/Home'

import AuthContext from './components/store/auth_context'
// import Switch from './switch/TogleSwitch'


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  useEffect(() => {
    const stored = localStorage.getItem('isLoggedIn')
    if (stored === '1') {
      setIsLoggedIn(true)
    }
  }, [])

  const loginHandler = async (email, password) => {
    // We should of course check email and password
    // But it's just a dummy/ demo anyways
    localStorage.setItem(email, password)
    setIsLoggedIn(true)
  }

  const logoutHandler = () => {
    localStorage.removeItem('isLoggedIn')
    setIsLoggedIn(false)
  }
const [switchState,setSwitchState]=useState(false)

  return (
    <div  style={{backgroundColor:!switchState ?"white" :"#282527" ,height:'50rem'}} >
    <AuthContext.Provider value={{isLoggedIn:isLoggedIn,onLogOut:logoutHandler, onSwitch:setSwitchState}} >
      <MainHeader />
      <main style={{margin:" 5rem"}}>
        {!isLoggedIn && <Login onLogin={loginHandler} />}  
         {isLoggedIn && <Home onLogout={logoutHandler} />} 
      </main>
    </AuthContext.Provider>
      {/* <Switch /> */}
    </div >
  )
}

export default App
