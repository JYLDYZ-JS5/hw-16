import React from 'react'

const AuthContext = React.createContext({
  isLoggedIn: undefined,
  onLogOut: () => {},
  
})
export default AuthContext
