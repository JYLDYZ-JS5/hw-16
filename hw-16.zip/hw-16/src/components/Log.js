import { useReducer } from 'react'

const reducerCount = (prevState, action) => {
  if (action.type === 'Plus') {
    return prevState + 1
  }
  if (action.type === 'Minus') {
    return prevState - 1
  }
}


function Counter() {
  const [counter, dispatchCounter] = useReducer(reducerCount, 0)

  const plusHandler = () => {
    dispatchCounter({ type: 'Plus' }) //почти всегда объект берилет   {type:'Plus'}- ACTION
  }

  const minusHandler=()=>{
    dispatchCounter({ type: 'Minus' })
  }
  return (
    <div>
      <h1>{counter}</h1>
      <button onClick={plusHandler}>+</button>
      <button onClick={minusHandler}>-</button>
    </div>
  )
}
export default Counter
