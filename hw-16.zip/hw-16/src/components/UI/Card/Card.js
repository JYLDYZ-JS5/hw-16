import React from 'react';
import { useState } from 'react';
import AuthContext from '../../store/auth_context';

import classes from './Card.module.css';

const Card = (props) => {
  const [switcher,setSwitch]=useState(false)
  return (
    <AuthContext.Provider value={{onSwitch:setSwitch}}>
    <div 
    className={`${classes.card} ${props.className}`}
    style={{backgroundColor:!switcher ?"white" :"#282527" }}
    >{props.children}</div>
    </AuthContext.Provider>
  );
};

export default Card;
