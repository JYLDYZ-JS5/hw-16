import React from 'react';
import Navigation from './Navigation';
import './MainHeader.css';
// import AuthContext from '../store/auth_context'
// import { useState } from 'react';
import '../UI/dark-Theme.css'

const MainHeader = (props) => {
  

  
  return (
    <header className='mainheader'>
      <h1>A Typical Page</h1>
      <Navigation />
    </header>
  );
};

export default MainHeader;
