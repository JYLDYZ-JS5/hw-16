import React, { useContext } from 'react'
import Switch from '../../switch/TogleSwitch'

import AuthContext from '../store/auth_context'
import './Navigation.css'

const Navigation = (props) => {
	//Cosumer  arkyluu globalnyi  sostoianiaga baardyk komponentter dostup  alat
	// return(
	// {
		/* <AuthContext.Consumer>
		{(contextData) => { */
	// }
	

	const contextData = useContext(AuthContext)
	return (

	<nav className="nav">
			<ul>
        <Switch />
				{contextData.isLoggedIn && (
					<li>
						<a href='/'>Users</a>
					</li>
				)}
				{contextData.isLoggedIn && (
					<li>
						<a href='/'>Admin</a>
					</li>
				)}
				{contextData.isLoggedIn && (
					<li>
						<button onClick={contextData.onLogOut}>Logout</button>
					</li>
				)}
			</ul>
		</nav>
		
	)
	// }}
	// </AuthContext.Consumer>
	// )
}

export default Navigation